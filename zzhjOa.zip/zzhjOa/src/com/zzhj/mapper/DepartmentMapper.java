package com.zzhj.mapper;

import java.util.List;

import com.zzhj.po.Department;

public interface DepartmentMapper {
	List<Department> queryAll();
}
